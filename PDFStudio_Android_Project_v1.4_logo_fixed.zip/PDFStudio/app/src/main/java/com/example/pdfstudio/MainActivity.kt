package com.example.pdfstudio

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    private val io = Executors.newSingleThreadExecutor()
    private var sourceFile: File? = null
    private var sourceName = ""
    private var sourcePassword: String? = null
    private var renderFile: File? = null
    private var descriptor: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null
    private var pageIndex = 0
    private val pageMarkups = mutableMapOf<Int, PdfMarkup>()
    private var pageView: PdfCanvasView? = null
    private var pageCounter: TextView? = null
    private var currentTool = PdfCanvasView.Tool.PEN
    private var savingFile: File? = null
    private val customFonts = mutableListOf<Pair<String, String>>()
    private var selectedFontPath: String? = null
    private var selectedTextColor: Int = Color.BLACK

    private val pickPdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importPdf(uri)
    }
    private val savePdf = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val temp = savingFile
        if (uri != null && temp != null) copySavedPdf(uri, temp)
    }
    private val pickFont = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            io.execute {
                try {
                    val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Custom font"
                    val ext = if (name.substringAfterLast('.', "ttf").lowercase() == "otf") "otf" else "ttf"
                    val file = File(filesDir, "font_${System.currentTimeMillis()}.$ext")
                    contentResolver.openInputStream(uri).use { input -> requireNotNull(input).use { src -> FileOutputStream(file).use { dst -> src.copyTo(dst) } } }
                    android.graphics.Typeface.createFromFile(file)
                    runOnUiThread {
                        customFonts.add(name to file.absolutePath)
                        selectedFontPath = file.absolutePath
                        Toast.makeText(this, "הגופן נוסף ונבחר: $name", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) { runOnUiThread { Toast.makeText(this, "לא ניתן לטעון גופן זה. בחר TTF או OTF תקין", Toast.LENGTH_LONG).show() } }
            }
        }
    }
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                contentResolver.openInputStream(uri).use { stream ->
                    val bitmap = android.graphics.BitmapFactory.decodeStream(stream)
                    if (bitmap != null) pageView?.addImage(bitmap) else Toast.makeText(this, "לא ניתן לקרוא את התמונה", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) { Toast.makeText(this, "טעינת התמונה נכשלה: ${e.message}", Toast.LENGTH_LONG).show() }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        window.decorView.systemUiVisibility = 0
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        buildHome()
    }

    private fun buildHome() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Ui.BG); isFillViewport = true }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(Ui.dp(this@MainActivity, 22), Ui.dp(this@MainActivity, 24), Ui.dp(this@MainActivity, 22), Ui.dp(this@MainActivity, 24))
        }
        scroll.addView(root)
        root.addView(Ui.text(this, "PDF STUDIO", 13f, Ui.ACCENT, true))
        root.addView(Ui.text(this, "כל המסמכים שלך.\nבמקום אחד.", 29f, Ui.TEXT, true).apply { setPadding(0, Ui.dp(this@MainActivity, 8), 0, Ui.dp(this@MainActivity, 8)) })
        root.addView(Ui.text(this, "קורא PDF נקי ונוח, עם כלי כתיבה, חתימה והדגשה.", 15f, Ui.MUTED))
        Ui.addGap(root, this, 24)

        val hero = Ui.panel(this)
        hero.background = Ui.rounded(0xFF211D38.toInt(), Ui.dp(this, 24), 0xFF383056.toInt())
        hero.addView(Ui.text(this, "▤", 42f, Ui.ACCENT, true).apply { gravity = Gravity.CENTER })
        hero.addView(Ui.text(this, "פתח מסמך PDF", 21f, Ui.TEXT, true).apply { gravity = Gravity.CENTER; setPadding(0, Ui.dp(this@MainActivity, 8), 0, 0) })
        hero.addView(Ui.text(this, "בחר קובץ מהמכשיר והתחל לקרוא או לסמן עליו.", 14f, Ui.MUTED).apply { gravity = Gravity.CENTER; setPadding(0, Ui.dp(this@MainActivity, 5), 0, Ui.dp(this@MainActivity, 14)) })
        val open = Ui.button(this, "בחירת קובץ PDF", true)
        hero.addView(open, LinearLayout.LayoutParams(-1, Ui.dp(this, 52)))
        open.setOnClickListener { pickPdf.launch(arrayOf("application/pdf")) }
        root.addView(hero)

        Ui.addGap(root, this, 20)
        root.addView(Ui.section(this, "כלי העריכה"))
        val featurePanel = Ui.panel(this)
        listOf(
            "✍  כתיבה וחתימה ביד" to "צייר עם האצבע ישירות על העמוד",
            "🟡  הדגשת קטעים" to "סמן משפטים ורעיונות חשובים",
            "T  הוספת טקסט ותמונות" to "הוסף תוכן חדש מעל העמוד",
            "Aa  החלפת טקסט קיים" to "כיסוי האזור הישן והצבת טקסט חדש בגופן דומה או מותאם",
            "🔤  פונטים אישיים" to "ייבוא גופני TTF ו־OTF מהמכשיר",
            "⤢  הגדלה והקטנה" to "זום בשתי אצבעות ואיפוס תצוגה",
            "🔒  פתיחת PDF מוגן" to "הזן סיסמה למסמכים נעולים",
            "⇩  שמירת עותק חדש" to "הקובץ המקורי נשאר ללא שינוי"
        ).forEachIndexed { index, pair ->
            featurePanel.addView(Ui.text(this, pair.first, 15f, Ui.TEXT, true))
            featurePanel.addView(Ui.text(this, pair.second, 13f, Ui.MUTED).apply { setPadding(0, Ui.dp(this@MainActivity, 3), 0, Ui.dp(this@MainActivity, 7)) })
            if (index != 5) {
                val divider = View(this).apply { setBackgroundColor(0xFF333348.toInt()) }
                featurePanel.addView(divider, LinearLayout.LayoutParams(-1, Ui.dp(this, 1)).apply { topMargin = Ui.dp(this@MainActivity, 5); bottomMargin = Ui.dp(this@MainActivity, 9) })
            }
        }
        root.addView(featurePanel)
        Ui.addGap(root, this, 16)
        root.addView(Ui.text(this, "אפשר להוסיף תמונות וטקסט כשכבה מעל העמוד. החלפה ישירה של טקסט מוטמע עדיין אינה נתמכת בכל סוגי ה‑PDF.", 12f, Ui.MUTED))
        setContentView(scroll)
    }

    private fun importPdf(uri: Uri) {
        Toast.makeText(this, "פותח את המסמך…", Toast.LENGTH_SHORT).show()
        io.execute {
            try {
                val file = File(cacheDir, "pdfstudio_input.pdf")
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "לא ניתן לקרוא את הקובץ" }
                    FileOutputStream(file).use { output -> input.copyTo(output) }
                }
                val name = uri.lastPathSegment?.substringAfterLast('/') ?: "מסמך PDF"
                runOnUiThread {
                    closePdf()
                    sourceFile = file
                    sourceName = name
                    sourcePassword = null
                    pageIndex = 0
                    pageMarkups.clear()
                    tryOpenPdf(file, null)
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "שגיאה בפתיחת הקובץ: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun tryOpenPdf(file: File, password: String?) {
        Toast.makeText(this, "בודק את מסמך ה‑PDF…", Toast.LENGTH_SHORT).show()
        io.execute {
            try {
                PDFBoxResourceLoader.init(applicationContext)
                val displayFile = if (password == null) {
                    // First try an ordinary, unprotected PDF. A failed open may indicate encryption.
                    try {
                        PDDocument.load(file).use { }
                        file
                    } catch (_: Exception) {
                        throw PasswordRequiredException()
                    }
                } else {
                    val decrypted = File(cacheDir, "pdfstudio_decrypted_${System.currentTimeMillis()}.pdf")
                    PDDocument.load(file, password).use { document -> document.isAllSecurityToBeRemoved = true; document.save(decrypted) }
                    decrypted
                }
                runOnUiThread {
                    try {
                        sourcePassword = password
                        renderFile = displayFile
                        descriptor = ParcelFileDescriptor.open(displayFile, ParcelFileDescriptor.MODE_READ_ONLY)
                        renderer = PdfRenderer(descriptor!!)
                        buildEditor()
                        renderPage()
                    } catch (e: Exception) {
                        Toast.makeText(this, "לא ניתן להציג את המסמך: ${e.message}", Toast.LENGTH_LONG).show()
                        buildHome()
                    }
                }
            } catch (_: PasswordRequiredException) {
                runOnUiThread { askPdfPassword(file) }
            } catch (e: Exception) {
                runOnUiThread {
                    val message = if (password != null) "סיסמה שגויה או קובץ פגום" else "לא הצלחתי לפתוח את ה‑PDF: ${e.message ?: "קובץ לא תקין"}"
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                    if (password != null) askPdfPassword(file) else buildHome()
                }
            }
        }
    }

    private class PasswordRequiredException : Exception()

    private fun askPdfPassword(file: File) {
        val field = EditText(this).apply {
            hint = "הזן סיסמת PDF"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.MUTED)
            textDirection = View.TEXT_DIRECTION_LTR
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("המסמך מוגן בסיסמה")
            .setMessage("הזן את הסיסמה כדי לפתוח את המסמך")
            .setView(field)
            .setNegativeButton("ביטול") { _, _ -> buildHome() }
            .setPositiveButton("פתיחה") { _, _ -> tryOpenPdf(file, field.text.toString()) }
            .setCancelable(false)
            .show()
    }

    private fun buildEditor() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Ui.BG)
            setPadding(Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 12))
        }
        val header = Ui.horizontal(this)
        val back = Ui.button(this, "‹  מסמכים")
        back.setOnClickListener { buildHome() }
        header.addView(back, LinearLayout.LayoutParams(Ui.dp(this, 112), Ui.dp(this, 44)))
        val titleColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(Ui.dp(this@MainActivity, 10), 0, 0, 0) }
        titleColumn.addView(Ui.text(this, "PDF STUDIO", 12f, Ui.ACCENT, true))
        titleColumn.addView(Ui.text(this, sourceName.ifBlank { "מסמך PDF" }, 13f, Ui.TEXT, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE })
        header.addView(titleColumn, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(header)

        val toolbarScroll = android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val toolbar = Ui.horizontal(this, 6)
        val pen = Ui.button(this, "✍ עט", true)
        val highlighter = Ui.button(this, "🟡 הדגשה")
        val addText = Ui.button(this, "T טקסט")
        val replaceText = Ui.button(this, "✎ החלפת טקסט")
        val fonts = Ui.button(this, "Aa גופנים")
        val undo = Ui.button(this, "↶ ביטול")
        val zoomReset = Ui.button(this, "⤢ איפוס זום")
        val addImage = Ui.button(this, "▧ תמונה")
        listOf(pen, highlighter, addText, replaceText, fonts, addImage, undo, zoomReset).forEach { toolbar.addView(it, LinearLayout.LayoutParams(Ui.dp(this, 112), Ui.dp(this, 44))) }
        zoomReset.setOnClickListener { pageView?.resetZoom() }
        addImage.setOnClickListener { pickImage.launch("image/*") }
        pen.setOnClickListener {
            currentTool = PdfCanvasView.Tool.PEN
            pageView?.setTool(currentTool)
            pen.background = Ui.rounded(Ui.ACCENT_2, Ui.dp(this, 14))
            highlighter.background = Ui.rounded(Ui.PANEL_2, Ui.dp(this, 14), 0xFF393950.toInt())
        }
        highlighter.setOnClickListener {
            currentTool = PdfCanvasView.Tool.HIGHLIGHTER
            pageView?.setTool(currentTool)
            highlighter.background = Ui.rounded(Ui.ACCENT_2, Ui.dp(this, 14))
            pen.background = Ui.rounded(Ui.PANEL_2, Ui.dp(this, 14), 0xFF393950.toInt())
        }
        addText.setOnClickListener { showTextDialog() }
        replaceText.setOnClickListener {
            currentTool = PdfCanvasView.Tool.REPLACE_TEXT
            pageView?.setTool(currentTool)
            Toast.makeText(this, "גרור עם האצבע סביב הטקסט שברצונך להחליף", Toast.LENGTH_LONG).show()
        }
        fonts.setOnClickListener { showFontManager() }
        pageView?.onReplaceRegion = { x, y, w, h -> showReplaceDialog(x, y, w, h) }
        undo.setOnClickListener { pageView?.undo() }
        toolbarScroll.addView(toolbar)
        root.addView(toolbarScroll, LinearLayout.LayoutParams(-1, Ui.dp(this, 52)))

        val viewFrame = FrameLayout(this).apply {
            background = Ui.rounded(0xFF252535.toInt(), Ui.dp(this@MainActivity, 18))
            clipToOutline = true
        }
        pageView = PdfCanvasView(this).apply { setTool(currentTool) }
        viewFrame.addView(pageView, FrameLayout.LayoutParams(-1, -1))
        root.addView(viewFrame, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = Ui.dp(this@MainActivity, 8); bottomMargin = Ui.dp(this@MainActivity, 8) })

        val nav = Ui.horizontal(this, 8)
        val prev = Ui.button(this, "עמוד קודם")
        val next = Ui.button(this, "עמוד הבא")
        pageCounter = Ui.text(this, "עמוד 1 מתוך 1", 14f, Ui.TEXT, true).apply { gravity = Gravity.CENTER }
        nav.addView(prev, LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1f))
        nav.addView(pageCounter, LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1f))
        nav.addView(next, LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1f))
        prev.setOnClickListener { changePage(-1) }
        next.setOnClickListener { changePage(1) }
        root.addView(nav)

        val save = Ui.button(this, "שמור עותק PDF מסומן", true)
        save.setOnClickListener {
            save.isEnabled = false
            save.text = "מכין את המסמך לשמירה…"
            io.execute {
                try {
                    val ready = savePdfToFile()
                    runOnUiThread {
                        savingFile = ready
                        save.isEnabled = true
                        save.text = "שמור עותק PDF מסומן"
                        savePdf.launch("${safeName(sourceName)}_edited.pdf")
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        save.isEnabled = true
                        save.text = "שמור עותק PDF מסומן"
                        Toast.makeText(this, "הכנת המסמך נכשלה: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
        root.addView(save, LinearLayout.LayoutParams(-1, Ui.dp(this, 50)).apply { topMargin = Ui.dp(this@MainActivity, 8) })
        setContentView(root)
    }

    private fun safeName(value: String): String {
        val base = value.substringBeforeLast('.', value).replace(Regex("[^\\p{L}\\p{N}_-]"), "_").take(32)
        return if (base.isBlank()) "document" else base
    }

    private fun showTextDialog() {
        val field = EditText(this).apply {
            hint = "כתוב טקסט להוספה על העמוד"
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.MUTED)
            textDirection = View.TEXT_DIRECTION_RTL
            setPadding(Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 12))
        }
        val colorButton = Ui.button(this, "צבע טקסט: ${String.format("#%06X", 0xFFFFFF and selectedTextColor)}")
        colorButton.setOnClickListener { showTextColorDialog { color ->
            selectedTextColor = color
            colorButton.text = "צבע טקסט: ${String.format("#%06X", 0xFFFFFF and color)}"
        } }
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(this@MainActivity, 18), 0, Ui.dp(this@MainActivity, 18), 0) }
        panel.addView(field)
        panel.addView(colorButton)
        android.app.AlertDialog.Builder(this)
            .setTitle("הוספת טקסט למסמך")
            .setView(panel)
            .setNegativeButton("ביטול", null)
            .setPositiveButton("הוסף") { _, _ -> pageView?.addText(field.text.toString(), selectedFontPath, selectedTextColor) }
            .show()
    }

    private fun showTextColorDialog(onSelected: (Int) -> Unit) {
        val colors = intArrayOf(Color.BLACK, Color.WHITE, Color.RED, 0xFF1565C0.toInt(), 0xFF008577.toInt(), 0xFF6A1B9A.toInt(), 0xFFFF8F00.toInt(), 0xFF795548.toInt(), 0xFF424242.toInt())
        val names = arrayOf("שחור", "לבן", "אדום", "כחול", "טורקיז", "סגול", "כתום", "חום", "אפור")
        var chosen = selectedTextColor
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(this@MainActivity, 18), Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 18), 0)
        }
        for (row in 0 until 3) {
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (column in 0 until 3) {
                val index = row * 3 + column
                val swatch = Ui.button(this, names[index])
                swatch.setBackgroundColor(colors[index])
                swatch.setTextColor(if (colors[index] == Color.WHITE || colors[index] == 0xFFFFD84D.toInt()) Color.BLACK else Color.WHITE)
                swatch.setOnClickListener { chosen = colors[index] }
                line.addView(swatch, LinearLayout.LayoutParams(0, Ui.dp(this, 42), 1f).apply { setMargins(Ui.dp(this@MainActivity, 3), Ui.dp(this@MainActivity, 3), Ui.dp(this@MainActivity, 3), Ui.dp(this@MainActivity, 3)) })
            }
            panel.addView(line)
        }
        val input = EditText(this).apply {
            hint = "קוד HEX, למשל #1565C0 (ריק = צבע מהלוח)"
            setSingleLine(true)
            setPadding(Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 10), Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 10))
        }
        panel.addView(input)
        android.app.AlertDialog.Builder(this).setTitle("בחירת צבע טקסט")
            .setView(panel)
            .setPositiveButton("אישור") { _, _ ->
                val raw = input.text.toString().trim()
                if (raw.isBlank()) onSelected(chosen)
                else try { onSelected(Color.parseColor(if (raw.startsWith("#")) raw else "#$raw")) }
                catch (_: Exception) { Toast.makeText(this, "קוד צבע לא תקין; נשמר הצבע שנבחר מהלוח", Toast.LENGTH_LONG).show(); onSelected(chosen) }
            }
            .setNegativeButton("ביטול", null).show()
    }

    private fun showFontManager() {
        val options = customFonts.map { it.first }.toMutableList()
        options.add(0, "גופן ברירת מחדל")
        options.add("＋ העלאת גופן מהמכשיר")
        android.app.AlertDialog.Builder(this).setTitle("בחירת גופן")
            .setItems(options.toTypedArray()) { _, which ->
                when {
                    which == options.lastIndex -> pickFont.launch(arrayOf("font/ttf", "font/otf", "application/octet-stream"))
                    which == 0 -> selectedFontPath = null
                    else -> selectedFontPath = customFonts[which - 1].second
                }
            }.setNegativeButton("סגור", null).show()
    }

    private fun showReplaceDialog(x: Float, y: Float, w: Float, h: Float) {
        val field = EditText(this).apply {
            hint = "הטקסט החדש"
            setTextColor(Ui.TEXT); setHintTextColor(Ui.MUTED)
            textDirection = View.TEXT_DIRECTION_RTL
            setPadding(Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 12))
        }
        val fontsButton = Ui.button(this, "גופן: ${customFonts.firstOrNull { it.second == selectedFontPath }?.first ?: "ברירת מחדל"}")
        fontsButton.setOnClickListener { showFontManager(); fontsButton.postDelayed({ fontsButton.text = "גופן: ${customFonts.firstOrNull { it.second == selectedFontPath }?.first ?: "ברירת מחדל"}" }, 400) }
        val colorButton = Ui.button(this, "צבע טקסט: ${String.format("#%06X", 0xFFFFFF and selectedTextColor)}")
        colorButton.setOnClickListener { showTextColorDialog { color ->
            selectedTextColor = color
            colorButton.text = "צבע טקסט: ${String.format("#%06X", 0xFFFFFF and color)}"
        } }
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(this@MainActivity, 18), 0, Ui.dp(this@MainActivity, 18), 0) }
        panel.addView(field)
        panel.addView(fontsButton)
        panel.addView(colorButton)
        android.app.AlertDialog.Builder(this).setTitle("החלפת אזור טקסט")
            .setMessage("בשלב זה זו שכבת תיקון: האפליקציה דוגמת את צבע הרקע באזור ומנסה להתאים אותו. זו עדיין אינה עריכה ישירה של אובייקט הטקסט המקורי; ברקע מדורג או בתמונה התוצאה עלולה לא להיות מדויקת.")
            .setView(panel)
            .setNegativeButton("ביטול", null)
            .setPositiveButton("החלף באזור המסומן") { _, _ ->
                pageView?.addReplacement(field.text.toString(), x, y, w, h, selectedFontPath, selectedTextColor)
                pageView?.setTool(PdfCanvasView.Tool.PEN)
                currentTool = PdfCanvasView.Tool.PEN
            }.show()
    }

    private fun changePage(delta: Int) {
        val count = renderer?.pageCount ?: return
        val next = (pageIndex + delta).coerceIn(0, count - 1)
        if (next == pageIndex) return
        pageIndex = next
        renderPage()
    }

    private fun renderPage() {
        val pdf = renderer ?: return
        try {
            val bitmap = pdf.openPage(pageIndex).use { page ->
                val maxWidth = 1600
                val factor = minOf(2.4f, maxWidth.toFloat() / page.width.toFloat())
                val width = (page.width * factor).roundToInt().coerceAtLeast(1)
                val height = (page.height * factor).roundToInt().coerceAtLeast(1)
                Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also { bmp ->
                    bmp.eraseColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                }
            }
            val marks = pageMarkups.getOrPut(pageIndex) { PdfMarkup() }
            pageView?.setPage(bitmap, marks)
            pageCounter?.text = "עמוד ${pageIndex + 1} מתוך ${pdf.pageCount}"
        } catch (e: Exception) {
            Toast.makeText(this, "לא ניתן להציג את העמוד: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun copySavedPdf(uri: Uri, temp: File) {
        io.execute {
            try {
                contentResolver.openOutputStream(uri, "w").use { output ->
                    requireNotNull(output) { "לא ניתן לשמור ליעד שנבחר" }
                    FileInputStream(temp).use { input -> input.copyTo(output) }
                }
                runOnUiThread { Toast.makeText(this, "המסמך נשמר בהצלחה", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "השמירה נכשלה: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun savePdfToFile(): File {
        val input = requireNotNull(sourceFile) { "לא נבחר מסמך" }
        PDFBoxResourceLoader.init(applicationContext)
        val output = File(cacheDir, "pdfstudio_edited_${System.currentTimeMillis()}.pdf")
        val loaded = if (sourcePassword.isNullOrEmpty()) PDDocument.load(input) else PDDocument.load(input, sourcePassword)
        loaded.use { document ->
            for (index in 0 until document.numberOfPages) {
                val markup = pageMarkups[index] ?: continue
                if (markup.strokes.isEmpty() && markup.texts.isEmpty() && markup.images.isEmpty()) continue
                val page = document.getPage(index)
                val pageWidth = page.mediaBox.width
                val pageHeight = page.mediaBox.height
                val bitmap = PdfCanvasView.renderMarkup(markup, (pageWidth * 2.4f).roundToInt(), (pageHeight * 2.4f).roundToInt())
                try {
                    val image = LosslessFactory.createFromImage(document, bitmap)
                    PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true, true).use { stream ->
                        stream.drawImage(image, 0f, 0f, pageWidth, pageHeight)
                    }
                } finally {
                    bitmap.recycle()
                }
            }
            document.save(output)
        }
        return output
    }

    override fun onBackPressed() {
        if (renderer != null) buildHome() else super.onBackPressed()
    }

    private fun closePdf() {
        try { renderer?.close() } catch (_: Exception) {}
        try { descriptor?.close() } catch (_: Exception) {}
        renderer = null
        descriptor = null
        renderFile = null
    }

    override fun onDestroy() {
        closePdf()
        io.shutdown()
        super.onDestroy()
    }
}
