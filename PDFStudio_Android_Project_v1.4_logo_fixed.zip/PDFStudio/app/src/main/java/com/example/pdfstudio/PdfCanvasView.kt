package com.example.pdfstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.min
import kotlin.math.max

internal data class MarkPoint(val x: Float, val y: Float)
internal data class MarkStroke(
    val points: MutableList<MarkPoint>,
    val color: Int,
    val width: Float,
    val alpha: Int
)
internal data class MarkText(val text: String, val x: Float, val y: Float, val color: Int = Color.BLACK, val width: Float = 0.72f, val height: Float = 0.12f, val fontPath: String? = null, val coverOriginal: Boolean = false, val coverColor: Int = Color.WHITE)
internal data class MarkImage(val bitmap: Bitmap, val x: Float = 0.18f, val y: Float = 0.25f, val width: Float = 0.64f, val height: Float = 0.42f)
internal data class PdfMarkup(
    val strokes: MutableList<MarkStroke> = mutableListOf(),
    val texts: MutableList<MarkText> = mutableListOf(),
    val images: MutableList<MarkImage> = mutableListOf()
)

/** A page canvas that keeps every annotation in normalized page coordinates. */
internal class PdfCanvasView(context: Context) : View(context) {
    enum class Tool { PEN, HIGHLIGHTER, REPLACE_TEXT }

    private var pageBitmap: Bitmap? = null
    private var markup: PdfMarkup = PdfMarkup()
    private var tool = Tool.PEN
    private var currentStroke: MarkStroke? = null
    private var selectionStart: MarkPoint? = null
    private var selectionRect: RectF? = null
    var onReplaceRegion: ((Float, Float, Float, Float) -> Unit)? = null
    private val pageRect = RectF()
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF252535.toInt() }
    private var zoom = 1f
    private var panX = 0f
    private var panY = 0f
    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val old = zoom
            zoom = (zoom * detector.scaleFactor).coerceIn(1f, 5f)
            val ratio = zoom / old
            panX = (detector.focusX - (detector.focusX - panX) * ratio)
            panY = (detector.focusY - (detector.focusY - panY) * ratio)
            if (zoom == 1f) { panX = 0f; panY = 0f }
            invalidate()
            return true
        }
    })

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        contentDescription = "תצוגת עמוד PDF לעריכה"
    }

    fun resetZoom() { zoom = 1f; panX = 0f; panY = 0f; invalidate() }

    fun setPage(bitmap: Bitmap, pageMarkup: PdfMarkup) {
        pageBitmap = bitmap
        resetZoom()
        markup = pageMarkup
        currentStroke = null
        invalidate()
    }

    fun setTool(value: Tool) { tool = value }
    fun getMarkup(): PdfMarkup = markup

    fun addText(value: String, fontPath: String? = null, color: Int = Color.BLACK) {
        if (value.isNotBlank()) {
            markup.texts.add(MarkText(value.trim(), 0.08f, 0.52f, color = color, fontPath = fontPath))
            invalidate()
        }
    }

    fun addReplacement(value: String, x: Float, y: Float, w: Float, h: Float, fontPath: String?, color: Int = Color.BLACK) {
        if (value.isNotBlank()) {
            val background = sampleBackgroundColor(x, y, w, h)
            markup.texts.add(MarkText(value.trim(), x, y, color = color, fontPath = fontPath, width = w, height = h, coverOriginal = true, coverColor = background))
            invalidate()
        }
    }

    /** Samples the selected page area for a best-effort solid-color patch. This is a fallback,
     * not true PDF text-object editing; textured/gradient/image backgrounds need reconstruction. */
    private fun sampleBackgroundColor(x: Float, y: Float, w: Float, h: Float): Int {
        val bitmap = pageBitmap ?: return Color.WHITE
        val left = (x * bitmap.width).toInt().coerceIn(0, bitmap.width - 1)
        val top = (y * bitmap.height).toInt().coerceIn(0, bitmap.height - 1)
        val right = ((x + w) * bitmap.width).toInt().coerceIn(left + 1, bitmap.width)
        val bottom = ((y + h) * bitmap.height).toInt().coerceIn(top + 1, bitmap.height)
        val insetX = ((right - left) * 0.12f).toInt()
        val insetY = ((bottom - top) * 0.12f).toInt()
        val xs = listOf(left + insetX, (left + right) / 2, right - 1 - insetX).distinct()
        val ys = listOf(top + insetY, bottom - 1 - insetY).distinct()
        var red = 0L; var green = 0L; var blue = 0L; var count = 0
        for (py in ys) for (px in xs) {
            val c = bitmap.getPixel(px.coerceIn(0, bitmap.width - 1), py.coerceIn(0, bitmap.height - 1))
            red += Color.red(c); green += Color.green(c); blue += Color.blue(c); count++
        }
        if (count == 0) return Color.WHITE
        return Color.rgb((red / count).toInt(), (green / count).toInt(), (blue / count).toInt())
    }

    fun addImage(bitmap: Bitmap) {
        markup.images.add(MarkImage(bitmap))
        invalidate()
    }

    fun undo() {
        if (markup.strokes.isNotEmpty()) markup.strokes.removeAt(markup.strokes.lastIndex)
        else if (markup.texts.isNotEmpty()) markup.texts.removeAt(markup.texts.lastIndex)
        else if (markup.images.isNotEmpty()) markup.images.removeAt(markup.images.lastIndex)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(0xFF252535.toInt())
        val bitmap = pageBitmap ?: return
        val fit = min(width.toFloat() / bitmap.width.toFloat(), height.toFloat() / bitmap.height.toFloat())
        val drawW = bitmap.width * fit
        val drawH = bitmap.height * fit
        val base = RectF((width - drawW) / 2f, (height - drawH) / 2f, (width + drawW) / 2f, (height + drawH) / 2f)
        val save = canvas.save()
        canvas.translate(panX, panY)
        canvas.scale(zoom, zoom, width / 2f, height / 2f)
        pageRect.set(base)
        pageRect.offset(panX, panY)
        val cx = width / 2f; val cy = height / 2f
        pageRect.set(cx + (pageRect.left - cx) * zoom, cy + (pageRect.top - cy) * zoom,
            cx + (pageRect.right - cx) * zoom, cy + (pageRect.bottom - cy) * zoom)
        canvas.drawRect(base, bgPaint)
        canvas.translate(base.left, base.top)
        canvas.scale(base.width(), base.height())
        canvas.drawBitmap(bitmap, null, RectF(0f, 0f, 1f, 1f), Paint(Paint.FILTER_BITMAP_FLAG))
        drawMarkupNormalized(canvas, markup)
        selectionRect?.let { r ->
            canvas.drawRect(r, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x553F8CFF; style = Paint.Style.FILL })
            canvas.drawRect(r, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF3F8CFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 0.003f })
        }
        canvas.restoreToCount(save)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val bitmap = pageBitmap ?: return false
        scaleDetector.onTouchEvent(event)
        if (event.pointerCount > 1) {
            if (event.actionMasked == MotionEvent.ACTION_POINTER_DOWN) currentStroke = null
            parent?.requestDisallowInterceptTouchEvent(true)
            return true
        }
        if (pageRect.width() <= 0f || pageRect.height() <= 0f) return false
        val x = ((event.x - pageRect.left) / pageRect.width()).coerceIn(0f, 1f)
        val y = ((event.y - pageRect.top) / pageRect.height()).coerceIn(0f, 1f)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!pageRect.contains(event.x, event.y)) return false
                if (tool == Tool.REPLACE_TEXT) {
                    selectionStart = MarkPoint(x, y)
                    selectionRect = RectF(x, y, x, y)
                    invalidate()
                    return true
                }
                val highlighter = tool == Tool.HIGHLIGHTER
                currentStroke = MarkStroke(
                    mutableListOf(MarkPoint(x, y)),
                    if (highlighter) 0xFFFFD84D.toInt() else 0xFF2F5EEA.toInt(),
                    if (highlighter) 0.018f else 0.006f,
                    if (highlighter) 92 else 255
                )
                markup.strokes.add(currentStroke!!)
                parent?.requestDisallowInterceptTouchEvent(true)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (tool == Tool.REPLACE_TEXT && selectionStart != null) {
                    val st = selectionStart!!
                    selectionRect = RectF(min(st.x, x), min(st.y, y), maxOf(st.x, x), maxOf(st.y, y))
                    invalidate()
                    return true
                }
                currentStroke?.points?.add(MarkPoint(x, y))
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (tool == Tool.REPLACE_TEXT && selectionStart != null) {
                    val r = selectionRect
                    if (r != null && r.width() > 0.015f && r.height() > 0.008f) onReplaceRegion?.invoke(r.left, r.top, r.width(), r.height())
                    selectionStart = null
                    selectionRect = null
                    invalidate()
                    return true
                }
                currentStroke?.points?.add(MarkPoint(x, y))
                currentStroke = null
                parent?.requestDisallowInterceptTouchEvent(false)
                invalidate()
                return true
            }
        }
        return true
    }

    companion object {
        fun renderMarkup(markup: PdfMarkup, width: Int, height: Int): Bitmap {
            val bitmap = Bitmap.createBitmap(width.coerceAtLeast(1), height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.scale(bitmap.width.toFloat(), bitmap.height.toFloat())
            drawMarkupNormalized(canvas, markup)
            return bitmap
        }

        private fun drawMarkupNormalized(canvas: Canvas, markup: PdfMarkup) {
            for (stroke in markup.strokes) {
                if (stroke.points.isEmpty()) continue
                val path = Path()
                path.moveTo(stroke.points.first().x, stroke.points.first().y)
                for (point in stroke.points.drop(1)) path.lineTo(point.x, point.y)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = stroke.color
                    alpha = stroke.alpha
                    style = Paint.Style.STROKE
                    strokeWidth = stroke.width
                    strokeCap = Paint.Cap.ROUND
                    strokeJoin = Paint.Join.ROUND
                }
                canvas.drawPath(path, paint)
            }
            for (item in markup.images) {
                canvas.drawBitmap(item.bitmap, null, RectF(item.x, item.y, item.x + item.width, item.y + item.height), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            }
            for (item in markup.texts) {
                if (item.coverOriginal) {
                    val cover = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = item.coverColor; style = Paint.Style.FILL }
                    canvas.drawRect(RectF(item.x, item.y, item.x + item.width, item.y + item.height), cover)
                }
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = item.color
                    textSize = 0.045f
                    style = Paint.Style.FILL
                    typeface = try { if (!item.fontPath.isNullOrBlank()) android.graphics.Typeface.createFromFile(item.fontPath) else android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD) } catch (_: Exception) { android.graphics.Typeface.DEFAULT_BOLD }
                }
                paint.textSize = if (item.coverOriginal) (item.height * 0.72f).coerceAtLeast(0.012f) else 0.045f
                val lines = item.text.split('\n')
                lines.forEachIndexed { index, line -> canvas.drawText(line, item.x, item.y + index * 0.055f, paint) }
            }
        }
    }
}
